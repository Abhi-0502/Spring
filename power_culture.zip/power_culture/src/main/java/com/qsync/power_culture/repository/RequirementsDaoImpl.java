package com.qsync.power_culture.repository;

public class RequirementsDaoImpl {
}
