package com.qsync.power_culture.repository;

public interface RequirementDao {
}
