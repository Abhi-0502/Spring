package com.qsync.power_culture.services;

public interface RequirementsServices {
}
