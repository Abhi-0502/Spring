package com.qsync.power_culture.configurationandwebinitializer;

import org.springframework.web.SpringServletContainerInitializer;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class Initializer extends AbstractAnnotationConfigDispatcherServletInitializer {


    @Override
    protected Class<?>[] getRootConfigClasses() {
        System.out.println("getRootConfigClasses is invoked");
        return new Class[0];
    }

    @Override
    protected Class<?>[] getServletConfigClasses() {
        System.out.println("getServletConfigClasses is invoked");
        return new Class[]{SpringServletContainerInitializer.class};
    }

    @Override
    protected String[] getServletMappings() {
        System.out.println("getServletMappings is invoked");
        return new String[]{"/"};
    }
}
